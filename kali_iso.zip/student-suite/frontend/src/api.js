// All backend calls go through here
async function request(path, method = "GET", body) {
  const res = await fetch("/api" + path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

export const api = {
  get: (p) => request(p),
  post: (p, b) => request(p, "POST", b),
  put: (p, b) => request(p, "PUT", b),
  del: (p) => request(p, "DELETE"),
};
