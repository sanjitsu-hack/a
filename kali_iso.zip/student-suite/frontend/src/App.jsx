import { useState } from "react";
import Students from "./components/Students.jsx";
import Todos from "./components/Todos.jsx";
import Calculator from "./components/Calculator.jsx";
import "./styles.css";

const TABS = [
  ["students", "Students", Students],
  ["todos", "To-do list", Todos],
  ["calc", "Calculator", Calculator],
];

export default function App() {
  const [tab, setTab] = useState("students");
  const Active = TABS.find((t) => t[0] === tab)[2];

  return (
    <div className="app">
      <header>
        <h1>Campus desk</h1>
        <nav>
          {TABS.map(([id, label]) => (
            <button key={id} className={tab === id ? "on" : ""} onClick={() => setTab(id)}>
              {label}
            </button>
          ))}
        </nav>
      </header>
      <main><Active /></main>
    </div>
  );
}
