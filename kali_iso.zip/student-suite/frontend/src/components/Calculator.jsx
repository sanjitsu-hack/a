import { useState } from "react";

const OPS = {
  "+": (a, b) => a + b,
  "−": (a, b) => a - b,
  "×": (a, b) => a * b,
  "÷": (a, b) => (b === 0 ? NaN : a / b),
};

export default function Calculator() {
  const [display, setDisplay] = useState("0");
  const [acc, setAcc] = useState(null);
  const [op, setOp] = useState(null);
  const [fresh, setFresh] = useState(true);
  const [history, setHistory] = useState("");

  const fmt = (n) => (isNaN(n) || !isFinite(n) ? "Error" : String(parseFloat(n.toPrecision(12))));

  const digit = (d) => {
    if (display === "Error") { setDisplay(d); setFresh(false); return; }
    if (fresh) { setDisplay(d === "." ? "0." : d); setFresh(false); return; }
    if (d === "." && display.includes(".")) return;
    setDisplay(display === "0" && d !== "." ? d : display + d);
  };

  const operate = (next) => {
    const cur = parseFloat(display);
    if (display === "Error") return;
    if (op && !fresh) {
      const r = OPS[op](acc, cur);
      setAcc(r); setDisplay(fmt(r));
      setHistory(`${fmt(r)} ${next}`);
    } else {
      setAcc(cur);
      setHistory(`${display} ${next}`);
    }
    setOp(next); setFresh(true);
  };

  const equals = () => {
    if (!op || display === "Error") return;
    const cur = parseFloat(display);
    const r = OPS[op](acc, cur);
    setHistory(`${fmt(acc)} ${op} ${fmt(cur)} =`);
    setDisplay(fmt(r)); setAcc(null); setOp(null); setFresh(true);
  };

  const clear = () => { setDisplay("0"); setAcc(null); setOp(null); setFresh(true); setHistory(""); };
  const negate = () => display !== "Error" && setDisplay(fmt(-parseFloat(display)));
  const percent = () => display !== "Error" && setDisplay(fmt(parseFloat(display) / 100));
  const back = () => {
    if (fresh || display === "Error") return;
    setDisplay(display.length > 1 && !(display.length === 2 && display[0] === "-") ? display.slice(0, -1) : "0");
  };

  const keys = [
    ["C", clear, "fn"], ["±", negate, "fn"], ["%", percent, "fn"], ["÷", () => operate("÷"), "op"],
    ["7", () => digit("7")], ["8", () => digit("8")], ["9", () => digit("9")], ["×", () => operate("×"), "op"],
    ["4", () => digit("4")], ["5", () => digit("5")], ["6", () => digit("6")], ["−", () => operate("−"), "op"],
    ["1", () => digit("1")], ["2", () => digit("2")], ["3", () => digit("3")], ["+", () => operate("+"), "op"],
    ["0", () => digit("0"), "zero"], [".", () => digit(".")], ["=", equals, "eq"],
  ];

  return (
    <section className="calc">
      <div className="screen">
        <small>{history || "\u00A0"}</small>
        <div>{display}</div>
      </div>
      <div className="keys">
        {keys.map(([label, fn, cls]) => (
          <button key={label} className={cls || ""} onClick={fn}>{label}</button>
        ))}
      </div>
      <button className="back" onClick={back}>Delete last digit</button>
    </section>
  );
}
