import { useState, useEffect } from "react";
import { api } from "../api.js";

export default function Todos() {
  const [todos, setTodos] = useState([]);
  const [text, setText] = useState("");
  const [filter, setFilter] = useState("all");
  const [error, setError] = useState("");

  const reload = () =>
    api.get("/todos").then(setTodos).catch(() => setError("Cannot reach the server. Is the backend running?"));
  useEffect(() => { reload(); }, []);

  const add = async () => {
    if (!text.trim()) return;
    try { await api.post("/todos", { text }); setText(""); setError(""); reload(); }
    catch (e) { setError(e.message); }
  };
  const toggle = async (t) => { await api.put("/todos/" + t.id, { done: !t.done }); reload(); };
  const remove = async (id) => { await api.del("/todos/" + id); reload(); };
  const clearDone = async () => { await api.del("/todos/completed"); reload(); };

  const shown = todos.filter((t) => filter === "all" || (filter === "done" ? t.done : !t.done));
  const left = todos.filter((t) => !t.done).length;

  return (
    <section>
      <div className="row">
        <input
          placeholder="What needs doing?"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && add()}
        />
        <button className="primary" onClick={add}>Add task</button>
      </div>
      {error && <p className="error">{error}</p>}

      <div className="row filters">
        {["all", "active", "done"].map((f) => (
          <button key={f} className={filter === f ? "on" : ""} onClick={() => setFilter(f)}>{f}</button>
        ))}
        <span className="muted">{left} left</span>
        {todos.some((t) => t.done) && <button onClick={clearDone}>Clear completed</button>}
      </div>

      {shown.length === 0 ? (
        <p className="empty">{todos.length ? "Nothing in this view." : "No tasks yet. Add one above."}</p>
      ) : (
        <ul className="todos">
          {shown.map((t) => (
            <li key={t.id} className={t.done ? "done" : ""}>
              <label>
                <input type="checkbox" checked={t.done} onChange={() => toggle(t)} />
                <span>{t.text}</span>
              </label>
              <button className="danger" onClick={() => remove(t.id)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
