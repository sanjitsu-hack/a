import { useState, useEffect } from "react";
import { api } from "../api.js";

const empty = { name: "", roll: "", course: "", marks: "" };
const grade = (m) => (m >= 80 ? "A" : m >= 60 ? "B" : m >= 40 ? "C" : "F");

export default function Students() {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState(empty);
  const [editId, setEditId] = useState(null);
  const [q, setQ] = useState("");
  const [error, setError] = useState("");

  const reload = () =>
    api.get("/students").then(setStudents).catch(() => setError("Cannot reach the server. Is the backend running?"));
  useEffect(() => { reload(); }, []);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const reset = () => { setForm(empty); setEditId(null); setError(""); };

  const save = async () => {
    try {
      if (editId) await api.put("/students/" + editId, form);
      else await api.post("/students", form);
      reset();
      reload();
    } catch (e) { setError(e.message); }
  };

  const edit = (s) => { setForm({ ...s, marks: String(s.marks) }); setEditId(s.id); setError(""); };
  const remove = async (id) => {
    await api.del("/students/" + id);
    if (editId === id) reset();
    reload();
  };

  const shown = students.filter((s) =>
    [s.name, s.roll, s.course].some((f) => f.toLowerCase().includes(q.toLowerCase()))
  );
  const avg = students.length ? (students.reduce((a, s) => a + s.marks, 0) / students.length).toFixed(1) : "–";

  return (
    <section>
      <div className="stats">
        <div><b>{students.length}</b><span>students</span></div>
        <div><b>{avg}</b><span>average marks</span></div>
        <div><b>{students.filter((s) => s.marks >= 40).length}</b><span>passing</span></div>
      </div>

      <div className="row wrap">
        <input placeholder="Name" value={form.name} onChange={set("name")} />
        <input placeholder="Roll no." value={form.roll} onChange={set("roll")} />
        <input placeholder="Course" value={form.course} onChange={set("course")} />
        <input placeholder="Marks (0-100)" type="number" value={form.marks} onChange={set("marks")} />
        <button className="primary" onClick={save}>{editId ? "Save changes" : "Add student"}</button>
        {editId && <button onClick={reset}>Cancel</button>}
      </div>
      {error && <p className="error">{error}</p>}

      <input className="search" placeholder="Search by name, roll or course" value={q} onChange={(e) => setQ(e.target.value)} />

      {shown.length === 0 ? (
        <p className="empty">{students.length ? "No students match your search." : "No students yet. Add the first one above."}</p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Roll</th><th>Name</th><th>Course</th><th>Marks</th><th>Grade</th><th></th></tr>
            </thead>
            <tbody>
              {shown.map((s) => (
                <tr key={s.id}>
                  <td>{s.roll}</td><td>{s.name}</td><td>{s.course}</td><td>{s.marks}</td>
                  <td><span className={"badge g" + grade(s.marks)}>{grade(s.marks)}</span></td>
                  <td className="actions">
                    <button onClick={() => edit(s)}>Edit</button>
                    <button className="danger" onClick={() => remove(s.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
