# Campus desk: Student Management + To-do List + Calculator

React (Vite) frontend and Node/Express backend.

## Folder layout
```
student-suite/
  backend/                  Express API (port 5000), saves to data.json
    server.js
    package.json
  frontend/                 React app (port 5173)
    index.html
    vite.config.js          proxies /api to the backend
    src/
      main.jsx
      App.jsx               tabs
      api.js                fetch helper
      styles.css
      components/
        Students.jsx
        Todos.jsx
        Calculator.jsx      runs fully in the browser
```

## How to run (needs Node.js 18+)
Open two terminals.

Terminal 1 (backend):
```
cd backend
npm install
npm start
```

Terminal 2 (frontend):
```
cd frontend
npm install
npm run dev
```
Open http://localhost:5173

## API endpoints
| Method | URL | What it does |
|---|---|---|
| GET | /api/students | list students |
| POST | /api/students | add student {name, roll, course, marks} |
| PUT | /api/students/:id | update student |
| DELETE | /api/students/:id | delete student |
| GET | /api/todos | list tasks |
| POST | /api/todos | add task {text} |
| PUT | /api/todos/:id | update task {done} or {text} |
| DELETE | /api/todos/:id | delete task |
| DELETE | /api/todos/completed | remove all done tasks |

## Notes for viva
- Data is stored in backend/data.json (created on first write), so it survives restarts.
- The Vite proxy avoids CORS problems in development; the backend also enables cors().
- Validation runs on the server (marks 0-100, unique roll number, required fields).
- The calculator uses a small state machine instead of eval().
