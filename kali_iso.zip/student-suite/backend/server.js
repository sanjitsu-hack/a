const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 5000;
const FILE = path.join(__dirname, "data.json");

app.use(cors());
app.use(express.json());

/* ---- tiny JSON-file "database" ---- */
const read = () => {
  try { return JSON.parse(fs.readFileSync(FILE, "utf8")); }
  catch { return { students: [], todos: [] }; }
};
const write = (data) => fs.writeFileSync(FILE, JSON.stringify(data, null, 2));

/* ---- validation ---- */
function checkStudent(b, students, ignoreId) {
  const name = String(b.name || "").trim();
  const roll = String(b.roll || "").trim();
  const course = String(b.course || "").trim();
  const marks = Number(b.marks);
  if (!name || !roll || !course) return { error: "Enter name, roll number and course." };
  if (b.marks === "" || b.marks == null || isNaN(marks) || marks < 0 || marks > 100)
    return { error: "Marks must be a number from 0 to 100." };
  if (students.some((s) => s.roll === roll && s.id !== ignoreId))
    return { error: "That roll number already exists." };
  return { value: { name, roll, course, marks } };
}

/* ================= STUDENTS ================= */
app.get("/api/students", (req, res) => res.json(read().students));

app.post("/api/students", (req, res) => {
  const db = read();
  const { error, value } = checkStudent(req.body, db.students);
  if (error) return res.status(400).json({ error });
  const student = { id: Date.now(), ...value };
  db.students.push(student);
  write(db);
  res.status(201).json(student);
});

app.put("/api/students/:id", (req, res) => {
  const db = read();
  const id = Number(req.params.id);
  const i = db.students.findIndex((s) => s.id === id);
  if (i < 0) return res.status(404).json({ error: "Student not found." });
  const { error, value } = checkStudent(req.body, db.students, id);
  if (error) return res.status(400).json({ error });
  db.students[i] = { id, ...value };
  write(db);
  res.json(db.students[i]);
});

app.delete("/api/students/:id", (req, res) => {
  const db = read();
  db.students = db.students.filter((s) => s.id !== Number(req.params.id));
  write(db);
  res.json({ ok: true });
});

/* ================= TODOS ================= */
app.get("/api/todos", (req, res) => res.json(read().todos));

app.post("/api/todos", (req, res) => {
  const text = String(req.body.text || "").trim();
  if (!text) return res.status(400).json({ error: "Task text is required." });
  const db = read();
  const todo = { id: Date.now(), text, done: false };
  db.todos.unshift(todo);
  write(db);
  res.status(201).json(todo);
});

// must come before "/api/todos/:id" so "completed" isn't read as an id
app.delete("/api/todos/completed", (req, res) => {
  const db = read();
  db.todos = db.todos.filter((t) => !t.done);
  write(db);
  res.json(db.todos);
});

app.put("/api/todos/:id", (req, res) => {
  const db = read();
  const t = db.todos.find((x) => x.id === Number(req.params.id));
  if (!t) return res.status(404).json({ error: "Task not found." });
  if (typeof req.body.done === "boolean") t.done = req.body.done;
  if (typeof req.body.text === "string" && req.body.text.trim()) t.text = req.body.text.trim();
  write(db);
  res.json(t);
});

app.delete("/api/todos/:id", (req, res) => {
  const db = read();
  db.todos = db.todos.filter((t) => t.id !== Number(req.params.id));
  write(db);
  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`API running at http://localhost:${PORT}`));
